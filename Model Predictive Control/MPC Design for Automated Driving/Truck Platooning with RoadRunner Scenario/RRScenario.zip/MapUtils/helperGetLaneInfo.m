function [lanes,laneBoundaries] = helperGetLaneInfo(varargin)
%helperGetLaneInfo gets map data from RoadRunner Scenario and pack it into
%lanes and lane boundaries
%   
% This is a helper script for example purposes and may be removed or
% modified in the future.

% Copyright 2021-2022 The MathWorks, Inc.

%% Read map data from SSE
if nargin ~= 1
    % Get Scenario Simulation variable
    rrSim = Simulink.ScenarioSimulation.find('ScenarioSimulation');
else
    rrSim = varargin{1};
end
% Read Map information
map = rrSim.getMap;
% Pack lane and lane boundaries
lanes = packLaneStruct(map.map.lanes);
laneBoundaries = packLaneBoundaryStruct(map.map.lane_boundaries);
end

function laneStruct = packLaneStruct(laneData)
% packLaneStruct packs lane data from map into 
% HelperRRDefaultData.lane format

% Initialize laneStruct
laneStruct = repmat(HelperRRDefaultData.lane, length(laneData), 1);
% Add lane information to laneStruct
for i = 1:length(laneData)
    lane = laneData(i);
    laneStruct(i,1).ID = char(lane.id(2:end-1));
    laneStruct(i,1).TravelDir = getTravelDir(lane.travel_dir,'TRAVEL_DIR_UNSPECIFIED','TRAVEL_DIR_UNDIRECTED','TRAVEL_DIR_FORWARD','TRAVEL_DIR_BACKWARD','TRAVEL_DIR_BIDIRECTIONAL');
    laneStruct(i,1).LaneType = getLaneTypes(lane.lane_type,'LANE_TYPE_UNSPECIFIED','LANE_TYPE_DRIVING','LANE_TYPE_SHOULDER','LANE_TYPE_BORDER','LANE_TYPE_RESTRICTED','LANE_TYPE_PARKING','LANE_TYPE_CURB','LANE_TYPE_SIDEWALK','LANE_TYPE_CENTER_TURN','LANE_TYPE_BIKING');
    laneStruct(i,1).RightLaneBoundary.ID        = char(lane.right_lane_boundary.reference.id(2:end-1));
    laneStruct(i,1).RightLaneBoundary.Alignment = getAlignment(lane.right_lane_boundary.alignment,'ALIGNMENT_UNSPECIFIED','ALIGNMENT_FORWARD','ALIGNMENT_BACKWARD');
    laneStruct(i,1).LeftLaneBoundary.ID        = char(lane.left_lane_boundary.reference.id(2:end-1));
    laneStruct(i,1).LeftLaneBoundary.Alignment = getAlignment(lane.left_lane_boundary.alignment,'ALIGNMENT_UNSPECIFIED','ALIGNMENT_FORWARD','ALIGNMENT_BACKWARD');
    % update geometry values
    control_points = lane.geometry.values;
    num_control_points = length(control_points);
    for j = 1 : num_control_points
        control_point = control_points(j);
        laneStruct(i).Geometry.ControlPoints.x(j,1) = control_point.x;
        laneStruct(i).Geometry.ControlPoints.y(j,1) = control_point.y;
        laneStruct(i).Geometry.ControlPoints.z(j,1) = control_point.z;
    end
    % update PredecessorLanes and SuccessorLanes
    laneStruct(i).PredecessorLanes = repmat(HelperRRDefaultData.alignmentSingle,length(lane.predecessors),1);
    for j = 1:length(lane.predecessors)
        laneStruct(i).PredecessorLanes(j,1).ID = char(lane.predecessors(j).reference.id(2:end-1));
        laneStruct(i).PredecessorLanes(j,1).Alignment = getAlignment(lane.predecessors(j).alignment,'ALIGNMENT_UNSPECIFIED','ALIGNMENT_FORWARD','ALIGNMENT_BACKWARD');
    end
    laneStruct(i).SuccessorLanes = repmat(HelperRRDefaultData.alignmentSingle,length(lane.successors),1);
    for j = 1:length(lane.successors)
        laneStruct(i).SuccessorLanes(j,1).ID = char(lane.successors(j).reference.id(2:end-1));
        laneStruct(i).SuccessorLanes(j,1).Alignment = getAlignment(lane.successors(j).alignment,'ALIGNMENT_UNSPECIFIED','ALIGNMENT_FORWARD','ALIGNMENT_BACKWARD');
    end
end
end

function laneBoundaryStruct = packLaneBoundaryStruct(laneBoundaryData)
% packLaneBoundaryStruct packs lane data from map into 
% HelperRRDefaultData.laneBoundary format

% Initialize laneBoundaryStruct
laneBoundaryStruct = repmat(HelperRRDefaultData.laneBoundary, length(laneBoundaryData), 1);
% Add lane boundary information to laneBoundaryStruct
for i = 1:length(laneBoundaryData)
    laneBoundary = laneBoundaryData(i);
    control_points = laneBoundary.geometry.values;
    num_control_points = length(control_points);
    for j = 1 : num_control_points
        control_point = control_points(j);
        laneBoundaryStruct(i,1).Geometry.ControlPoints.x(j,1) = control_point.x;
        laneBoundaryStruct(i,1).Geometry.ControlPoints.y(j,1) = control_point.y;
        laneBoundaryStruct(i,1).Geometry.ControlPoints.z(j,1) = control_point.z;
    end
    laneBoundaryStruct(i,1).ID = char(laneBoundary.id(2:end-1));
end
end

function laneType = getLaneTypes(lane_type,LANE_TYPE_UNSPECIFIED,LANE_TYPE_DRIVING,LANE_TYPE_SHOULDER,LANE_TYPE_BORDER,LANE_TYPE_RESTRICTED,LANE_TYPE_PARKING,LANE_TYPE_CURB,LANE_TYPE_SIDEWALK,LANE_TYPE_CENTER_TURN,LANE_TYPE_BIKING)
%getLaneTypes updates the lane type.
    laneType = LaneType.LANE_TYPE_UNSPECIFIED;
    if lane_type == LANE_TYPE_UNSPECIFIED
        laneType = LaneType.LANE_TYPE_UNSPECIFIED;
    elseif lane_type == LANE_TYPE_DRIVING
        laneType = LaneType.LANE_TYPE_DRIVING;
    elseif lane_type == LANE_TYPE_SHOULDER
        laneType = LaneType.LANE_TYPE_SHOULDER;
    elseif lane_type == LANE_TYPE_BORDER
        laneType = LaneType.LANE_TYPE_BORDER;
    elseif lane_type == LANE_TYPE_RESTRICTED
        laneType = LaneType.LANE_TYPE_RESTRICTED;
    elseif lane_type == LANE_TYPE_PARKING
        laneType = LaneType.LANE_TYPE_PARKING;
    elseif lane_type == LANE_TYPE_CURB
        laneType = LaneType.LANE_TYPE_CURB;
    elseif lane_type == LANE_TYPE_SIDEWALK
        laneType = LaneType.LANE_TYPE_SIDEWALK;
    elseif lane_type == LANE_TYPE_CENTER_TURN
        laneType = LaneType.LANE_TYPE_CENTER_TURN;
    elseif lane_type == LANE_TYPE_BIKING
        laneType = LaneType.LANE_TYPE_BIKING;
    end
end

function travelDir = getTravelDir(travel_dir,TRAVEL_DIR_UNSPECIFIED,TRAVEL_DIR_UNDIRECTED,TRAVEL_DIR_FORWARD,TRAVEL_DIR_BACKWARD,TRAVEL_DIR_BIDIRECTIONAL)
%getTravelDir updates the travel direction.
    travelDir = TravelDir.TRAVEL_DIR_UNSPECIFIED;
    if travel_dir == TRAVEL_DIR_UNSPECIFIED
        travelDir = TravelDir.TRAVEL_DIR_UNSPECIFIED;
    elseif travel_dir == TRAVEL_DIR_UNDIRECTED
        travelDir = TravelDir.TRAVEL_DIR_UNDIRECTED;
    elseif travel_dir == TRAVEL_DIR_FORWARD
        travelDir = TravelDir.TRAVEL_DIR_FORWARD;
    elseif travel_dir == TRAVEL_DIR_BACKWARD
        travelDir = TravelDir.TRAVEL_DIR_BACKWARD;
    elseif travel_dir == TRAVEL_DIR_BIDIRECTIONAL
        travelDir = TravelDir.TRAVEL_DIR_BIDIRECTIONAL;
    end
end

function alignment =  getAlignment(alignmentIn,ALIGNMENT_UNSPECIFIED,ALIGNMENT_FORWARD,ALIGNMENT_BACKWARD)
%getAlignment outputs the correspoding alignment value.
    alignment = Alignment.ALIGNMENT_UNSPECIFIED;
    if alignmentIn == ALIGNMENT_UNSPECIFIED
        alignment = Alignment.ALIGNMENT_UNSPECIFIED; 
    elseif alignmentIn == ALIGNMENT_FORWARD
        alignment = Alignment.ALIGNMENT_FORWARD;
    elseif alignmentIn == ALIGNMENT_BACKWARD
        alignment = Alignment.ALIGNMENT_BACKWARD;
    end
end

