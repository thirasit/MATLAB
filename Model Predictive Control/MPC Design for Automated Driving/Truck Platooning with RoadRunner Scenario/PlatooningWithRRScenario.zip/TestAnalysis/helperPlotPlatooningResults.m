function hFig = helperPlotPlatooningResults(simLog,followers,platoonLeaderID,f1Out,f2Out)
%helperPlotPlatooningResults is a helper function to plot the
% simulation results for the platooning with roadrunner example. This
% function displays the longitudinal and lateral controller performances
%
% This helper script is for example purposes and may be removed or modified
% in the future.

% Copyright 2022 The MathWorks, Inc.

    % Create the figure window
    figureName = 'Platooning with RoadRunner Simulation Results';
    hFig = findobj('Type','Figure','Name',figureName);
    
    % create the figure only if it is not already open.
    if isempty(hFig)
        hFig = figure('Name',figureName);
        hFig.NumberTitle = "off";
        hFig.Visible = "on";
        scrsz = double(get(groot,'ScreenSize'));
        hFig.Position = [70 70 scrsz(3)*0.85 scrsz(4)*0.8];
    end
    
    % Clear figure.
    clf(hFig);  
    
    % Create UI panel for longitudianl control
    longControlPanel = uipanel(hFig,"Title","Longitudinal Controller Performance","Units","normalized","Position",[0 0 0.5 1],"BackgroundColor",'#e3e1da',"FontSize",15,"BorderType","none");
    
    % Create UI panel for velocity plot
    velocityPanel = uipanel(hFig,"Title","Velocity","Units","normalized","Position",[0 0.475 0.5 0.475],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Create UI panel for spacing plot
    spacingPanel = uipanel(hFig,"Title","Spacing","Units","normalized","Position",[0 0 0.5 0.475],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Create UI panel for lateral control
    latControlPanel = uipanel(hFig,"Title","Lateral Controller Performance","Units","normalized","Position",  [0.5 0 0.5 1],"BackgroundColor",'#e3e1da',"FontSize",15,"BorderType","none");
    
    % Create UI panel for lateral deviation
    latDeviationPanel = uipanel(hFig,"Title","Lateral Deviation","Units","normalized","Position",  [0.5 0 0.5 0.2375],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Create UI panel for relative yaw angle
    relativeYawPanel = uipanel(hFig,"Title","Relative Yaw Angle","Units","normalized","Position",  [0.5 0.2375 0.5 0.2375],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Create UI panel for steering
    steeringAnglePanel = uipanel(hFig,"Title","Steering","Units","normalized","Position", [0.5 0.475 0.5 0.2375],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Create UI panel for lane curvature
    laneCurvaturePanel = uipanel(hFig,"Title","Lane Curvature","Units","normalized","Position", [0.5 0.7125 0.5 0.2375],"BackgroundColor",[1 1 1],"FontSize",10);
    
    % Get time values
    t = get(simLog,'Time');
    numOfSteps = numel(t);    

    % Create drop down for lateral control performance
    hDropDown = uicontrol(hFig,"Style","popupmenu",'Units','normalized','Position',[0.85,0.91,0.15,0.075]);
    hDropDown.String = {"Follower1","Follower2","Both"};
    %% Velocity Plot 
    
    % Velocity plot axes
    velPlotAxes = axes(velocityPanel);
    hold(velPlotAxes,"on")
    grid(velPlotAxes,"on")

    % Get leader and follower velocities
	leaderVelocity  = get(simLog,'Velocity','ActorID',platoonLeaderID);
    velocity.Leader = arrayfun(@(veh) norm(veh.Velocity),leaderVelocity);

    follower1Velocity  = get(simLog,'Velocity','ActorID',followers(1).TractorID);
    velocity.Follower1 = arrayfun(@(veh) norm(veh.Velocity),follower1Velocity);

    follower2Velocity  = get(simLog,'Velocity','ActorID',followers(2).TractorID);
    velocity.Follower2 = arrayfun(@(veh) norm(veh.Velocity),follower2Velocity);

    % Set velocity plots
    velocityPlot.Leader    = plot(velPlotAxes,0,0,'r');
    set(velocityPlot.Leader,'XData',[],'YData',[]);
    velocityPlot.Follower1 = plot(velPlotAxes,0,0,'b');
    set(velocityPlot.Follower1,'XData',[],'YData',[]);
    velocityPlot.Follower2 = plot(velPlotAxes,0,0,'g');
    set(velocityPlot.Follower2,'XData',[],'YData',[]);

    % Display legend
    velPlotLegendStr = {"Leader","Follower1","Follower2"};
    legend(velPlotAxes,velPlotLegendStr)
    xlabel(velPlotAxes,"Time (sec)")
    ylabel(velPlotAxes,"Velocity (m/s)")
    %% Spacing Plot

    % Spacing plot axes
    spacingPlotAxes = axes(spacingPanel);
    hold(spacingPlotAxes,"on")
    grid(spacingPlotAxes,"on")
    
    % Get vehicle poses
    leaderPose    = get(simLog,"Pose",'ActorID',platoonLeaderID);
    follower1Pose = get(simLog,"Pose",'ActorID',followers(1).TractorID);
    follower2Pose = get(simLog,"Pose",'ActorID',followers(2).TractorID);

    % Compute spacing
    spacing.Expected = repmat(evalin("base","L"), size(t));
    spacing.LeaderToFollower1    = arrayfun(@(veh1,veh2) norm(veh1.Pose(1:3,4) - veh2.Pose(1:3,4)),leaderPose,follower1Pose);
    spacing.Follower1ToFollower2 = arrayfun(@(veh1,veh2) norm(veh1.Pose(1:3,4) - veh2.Pose(1:3,4)),follower1Pose,follower2Pose);
  
    % Plot spacing
    spacingPlot.Expected = plot(spacingPlotAxes,0,0,'--r');
    set(spacingPlot.Expected,'XData',[],'YData',[]);
    spacingPlot.LeaderToFollower1 = plot(spacingPlotAxes,0,0,'r');
    set(spacingPlot.LeaderToFollower1,'XData',[],'YData',[]);
    spacingPlot.Follower1ToFollower2 = plot(spacingPlotAxes,0,0,'g');
    set(spacingPlot.Follower1ToFollower2,'XData',[],'YData',[]);

    % Display legend
    spacingPlotLegendStr = {"Expected Spacing","Between Leader and Follower1","Between Follower1 and Follower2"};
    legend(spacingPlotAxes,spacingPlotLegendStr);
    xlabel(spacingPlotAxes,"Time (sec)")
    ylabel(spacingPlotAxes,"Spacing (m)")
    %% Lateral Deviation
    % Lateral deviation plot axes
    lateralDeviationAxes = axes(latDeviationPanel);
    hold(lateralDeviationAxes,"on")
    grid(lateralDeviationAxes,"on")

    % Get data
    lateralDeviation.Follower1 = reshape(f1Out.logsout.get("lateral_deviation").Values.Data,size(t));
    lateralDeviation.Follower2 = reshape(f2Out.logsout.get("lateral_deviation").Values.Data,size(t));

    % Setup lateral deviation plot
    lateralDeviationPlot.Follower1 = plot(lateralDeviationAxes,0,0,'b','LineWidth',0.01);
    set(lateralDeviationPlot.Follower1,'XData',[],'YData',[])

    lateralDeviationPlot.Follower2 = plot(lateralDeviationAxes,0,0,'g');
    set(lateralDeviationPlot.Follower2,'XData',[],'YData',[])
    
    legend(lateralDeviationAxes,{"Follower1","Follower2"})
    xlabel(lateralDeviationAxes,"Time (sec)")
    ylabel(lateralDeviationAxes,"Lateral Deviation (m)")
    %% Relative Yaw
    % relative yaw angle plot axes
    relativeYawAxes = axes(relativeYawPanel);
    hold(relativeYawAxes,"on")
    grid(relativeYawAxes,"on")

    % Get data
    relativeYaw.Follower1 = rad2deg(reshape(f1Out.logsout.get("relative_yaw").Values.Data,size(t)));
    relativeYaw.Follower2 = rad2deg(reshape(f2Out.logsout.get("relative_yaw").Values.Data,size(t)));

    % Setup relative yaw plot
    relativeYawPlot.Follower1 = plot(relativeYawAxes,0,0,'b');
    set(relativeYawPlot.Follower1,'XData',[],'YData',[])
    relativeYawPlot.Follower2 = plot(relativeYawAxes,0,0,'g');
    set(relativeYawPlot.Follower2,'XData',[],'YData',[])
    legend(relativeYawAxes,{"Follower1","Follower2"})
    xlabel(relativeYawAxes,"Time (sec)")
    ylabel(relativeYawAxes,"Relative Yaw Angle (deg)")
    %% Steering Angle
    % Lateral deviation plot axes
    steeringAngleAxes = axes(steeringAnglePanel);
    hold(steeringAngleAxes,"on")
    grid(steeringAngleAxes,"on")

    % Get data
    steeringAngle.Follower1 = rad2deg(reshape(f1Out.logsout.get("steering").Values.Data,size(t)));
    steeringAngle.Follower2 = rad2deg(reshape(f2Out.logsout.get("steering").Values.Data,size(t)));

    steeringAnglePlot.Follower1 = plot(steeringAngleAxes,0,0,'b');
    set(steeringAnglePlot.Follower1,'XData',[],'YData',[])
    steeringAnglePlot.Follower2 = plot(steeringAngleAxes,0,0,'g');
 
    set(steeringAnglePlot.Follower2,'XData',[],'YData',[])
    legend(steeringAngleAxes,{"Follower1","Follower2"})
    xlabel(steeringAngleAxes,"Time (sec)")
    ylabel(steeringAngleAxes,"Steering Angle (deg)")
    %% Lane Curvature
    %  Lane Curvature plot axes
    laneCurvatureAxes = axes(laneCurvaturePanel);
    hold(laneCurvatureAxes,"on")
    grid(laneCurvatureAxes,"on")
    
    % Get data
    laneCurvature = reshape(f1Out.logsout.get("lane_curvature").Values.Data(1,:,:),size(t));
    
    % Setup lane curvature plot
    laneCurvaturePlot = plot(laneCurvatureAxes,0,0,'b','LineWidth',0.01);
    set(laneCurvaturePlot,'XData',[],'YData',[])
    
    legend(laneCurvatureAxes,{"Curvature"})
    xlabel(laneCurvatureAxes,"Time (sec)")
    ylabel(laneCurvatureAxes,"Curvature (rad/s)")
    %% Slider
    % Callback for the dropdown
    hDropDown.Callback = @(src, event) stepSimulation(hDropDown,t,velocity,velocityPlot,spacing,spacingPlot,laneCurvature,laneCurvaturePlot,lateralDeviation,lateralDeviationPlot,relativeYaw,relativeYawPlot,steeringAngle,steeringAnglePlot);   

    % Display lateral control performance of both the followers
    hDropDown.Value = 3;

    stepSimulation(hDropDown,t,velocity,velocityPlot,spacing,spacingPlot,laneCurvature,laneCurvaturePlot,lateralDeviation,lateralDeviationPlot,relativeYaw,relativeYawPlot,steeringAngle,steeringAnglePlot)
end

function stepSimulation(hDropDown,t,velocity,velocityPlot,spacing,spacingPlot,laneCurvature,laneCurvaturePlot,lateralDeviation,lateralDeviationPlot,relativeYaw,relativeYawPlot,steeringAngle,steeringAnglePlot)
   % Update velocity plots
   set(velocityPlot.Leader,   'XData',t(1:end),'YData',velocity.Leader(1:end));
   set(velocityPlot.Follower1,'XData',t(1:end),'YData',velocity.Follower1(1:end));
   set(velocityPlot.Follower2,'XData',t(1:end),'YData',velocity.Follower2(1:end));

   % Update Spacing plots
   set(spacingPlot.Expected,            'XData',t(1:end),'YData',spacing.Expected(1:end));
   set(spacingPlot.LeaderToFollower1,   'XData',t(1:end),'YData',spacing.LeaderToFollower1(1:end));
   set(spacingPlot.Follower1ToFollower2,'XData',t(1:end),'YData',spacing.Follower1ToFollower2(1:end));

   set(laneCurvaturePlot,'XData',t(1:end),'YData',laneCurvature(1:end))

   if hDropDown.Value == 3 % Display Both
       % Update lateral deviation plots
       set(lateralDeviationPlot.Follower1,'XData',t(1:end),'YData',lateralDeviation.Follower1(1:end))
       set(lateralDeviationPlot.Follower2,'XData',t(1:end),'YData',lateralDeviation.Follower2(1:end))
        
       % Update relative yaw plots
       set(relativeYawPlot.Follower1,'XData',t(1:end),'YData',relativeYaw.Follower1(1:end))
       set(relativeYawPlot.Follower2,'XData',t(1:end),'YData',relativeYaw.Follower2(1:end))
    
       % Update steering angle plots
       set(steeringAnglePlot.Follower1,'XData',t(1:end),'YData',steeringAngle.Follower1(1:end))
       set(steeringAnglePlot.Follower2,'XData',t(1:end),'YData',steeringAngle.Follower2(1:end))
   elseif hDropDown.Value == 2 % Display only Follower2
       % Update lateral deviation plots
       set(lateralDeviationPlot.Follower1,'XData',[],'YData',[])
       set(lateralDeviationPlot.Follower2,'XData',t(1:end),'YData',lateralDeviation.Follower2(1:end))
    
       % Update relative yaw plots
       set(relativeYawPlot.Follower1,'XData',[],'YData',[])
       set(relativeYawPlot.Follower2,'XData',t(1:end),'YData',relativeYaw.Follower2(1:end))
    
       % Update steering angle plots
       set(steeringAnglePlot.Follower1,'XData',[],'YData',[])
       set(steeringAnglePlot.Follower2,'XData',t(1:end),'YData',steeringAngle.Follower2(1:end))
   else % Display only follower 1
       % Update lateral deviation plots
       set(lateralDeviationPlot.Follower1,'XData',t(1:end),'YData',lateralDeviation.Follower1(1:end))
       set(lateralDeviationPlot.Follower2,'XData',[],'YData',[])
    
       % Update relative yaw plots
       set(relativeYawPlot.Follower1,'XData',t(1:end),'YData',relativeYaw.Follower1(1:end))
       set(relativeYawPlot.Follower2,'XData',[],'YData',[])
    
       % Update steering angle plots
       set(steeringAnglePlot.Follower1,'XData',t(1:end),'YData',steeringAngle.Follower1(1:end))
       set(steeringAnglePlot.Follower2,'XData',[],'YData',[])
   end

   drawnow;
end