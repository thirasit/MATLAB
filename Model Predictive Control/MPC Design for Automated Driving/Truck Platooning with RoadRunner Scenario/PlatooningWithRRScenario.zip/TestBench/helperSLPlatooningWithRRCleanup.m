% Clean up script for the Platooning With RoadRunner Example
%
% This script cleans up the base workspace variables created by the example
% model. It is triggered by the CloseFcn callback of the follower models.
%
% This is a helper script for example purposes and may be removed or
% modified in the future.

% Copyright 2022 The MathWorks, Inc.

clear A B C
clear platoonLeaderID
clear maxSteer minSteer
clear modelName
clear followers
clear actorProfiles
clear predictionHorizon
clear egoRefPath
clear C1
clear channelAttributes
clear czWhlAxl
clear f0zWhlAxl
clear hMax
clear hitch
clear initialActorPose
clear K1
clear K2
clear kzWhlAxl
clear L
clear N
clear sceneOrigin
clear trailer
clear tractorTrailerID
clear egoID
clear Ts
clear tractor
clear vehicleDimension
clear V2VRange
clear spacing
clear allActorSimulationObj

clearBuses({'BusAccelerationSet4Way',...
            'BusActionComplete',...
            'BusActorPose',...
            'BusActorRuntime',...
            'BusActorsEgo',...
            'BusBrakeSystemStatus',...
            'BusBSM', ...
            'BusBSMCoreData',...
            'BusDiagnostics', ...
            'BusLeadAndFrontInfo',...
            'BusPositionalAccuracy',...
            'BusTargetActorPose',...
            'BusActorsInfo',...
            'BusVehicleLocationOnLane',...
            'BusVehicleMapLocation',... 
            'BusVehiclePose',...
            'BusVehicleRuntime',...
            'BusEgoRefPath',...
            'BusVehicleSize'})

function clearBuses(buses)
matlabshared.tracking.internal.DynamicBusUtilities.removeDefinition(buses);
end