classdef HelperGetTargetActorsAndEgoTrailerID < matlab.System
%HelperGetTargetActorsAndEgoTrailerID gets the target actors information
%   from rrscenario all actor runtime. This system object also finds the
%   ego's trailer ID
%
%   This is a helper file for example purposes and may be removed or
%   modified in the future.

% Copyright 2022-2023 The MathWorks, Inc.

    properties(Nontunable)
        % Sample Time
        SampleTime(1,1) double {mustBePositive, mustBeReal} = 0.02;
        % Actor Profiles
        ActorProfiles = struct;
        % Output Struct
        OutputStruct = struct;
    end

    properties (Access = private)
        % Number Of Actors
        NumActors
        
        % Previous Vehicle Velocity
        PrevVelocity

        % ID of vehicles which has a parent attachement
        AllChildrenID

        % Parent ID of each Actor
        SelfAndParentID = []; 
    end
    methods(Access = protected)

        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj,'Type','Discrete','SampleTime',obj.SampleTime);
        end

        function setupImpl(obj)
            ss = Simulink.ScenarioSimulation.find('ScenarioSimulation', 'SystemObject', obj);
            allActorSimulationObj = ss.get('ActorSimulation');% This will return all the actors currently exist in the simulation

            % Assign all ActorSimulation object to the base workspace.
            assignin("base","allActorSimulationObj",allActorSimulationObj)


            obj.NumActors = length(allActorSimulationObj);

            % Find ego and other trailer ID's to define the classID for
            % each vehicle.
            for i = 2:length(allActorSimulationObj)
                actor = allActorSimulationObj(i);
                selfID = actor.getAttribute('ID');
                parent = actor.getAttribute('Parent');
                parentID = parent.getAttribute('ID');
                obj.SelfAndParentID = [obj.SelfAndParentID; [selfID,parentID]];
            end

            % Get all vehicles which are attached to a parent, to set their
            % class Id.
            obj.AllChildrenID = obj.SelfAndParentID((obj.SelfAndParentID(:,2)>0),1);

            % Initialize the velocity
            obj.PrevVelocity = zeros(obj.NumActors-1,4);
            for i = 1:obj.NumActors
                actor = allActorSimulationObj(i);
                vel = actor.getAttribute('Velocity');
                Id = actor.getAttribute('ID');
                obj.PrevVelocity(i,:) = [Id vel];
            end
        end

        function icon = getIconImpl(obj)
            % Define the class name as icon for system block and raise it
            % above the center.
            icon = ["HelperGetTargetActorsAndEgoTrailerID","",""]; 
        end

        function [actorsInfo, egoTrailerID] = stepImpl(obj, egoID, allActorRuntime)
            egoTrailerID = uint64(obj.SelfAndParentID((obj.SelfAndParentID(:,2)==egoID),1));
            
            % Get target actor pose
            actorsInfo = obj.OutputStruct;
            numActors = 1;
            for i=1:length(allActorRuntime)
                if double(allActorRuntime(i).ActorID) ~= egoID && double(allActorRuntime(i).ActorID) ~= 0
                    % In world coordinates
                    rotationMatrix = allActorRuntime(i).Pose(1:3,1:3);
                    rotation = rotm2eul(rotationMatrix); % The default order for Euler angle rotations is "ZYX"
                    rotation = rad2deg(rotation);
                    location = allActorRuntime(i).Pose(1:3,4)';

                    actorID = double(allActorRuntime(i).ActorID);
                    if ismember(actorID,obj.AllChildrenID) 
                        classID = double(8);
                    else
                        classID = double(2);
                    end
                    acc = (double(allActorRuntime(i).Velocity) - double(obj.PrevVelocity(obj.PrevVelocity(:,1) == actorID,2:end)))/obj.SampleTime;
                    actorsInfo.Actors(numActors).ActorID  = actorID;
                    actorsInfo.Actors(numActors).ClassID  = classID;
                    actorsInfo.Actors(numActors).Position = location;
                    actorsInfo.Actors(numActors).Velocity = allActorRuntime(i).Velocity;
                    actorsInfo.Actors(numActors).Acceleration = double(acc);
                    actorsInfo.Actors(numActors).Roll     = rotation(3);
                    actorsInfo.Actors(numActors).Pitch    = rotation(2);
                    actorsInfo.Actors(numActors).Yaw      = rotation(1) + 90;
                    actorsInfo.Actors(numActors).AngularVelocity = rad2deg(allActorRuntime(i).AngularVelocity);

                    idx = [obj.ActorProfiles.ActorID] == actorID;
                    actorsInfo.Actors(numActors).Length   = obj.ActorProfiles(idx).Length; % Get Length
                    actorsInfo.Actors(numActors).Width    = obj.ActorProfiles(idx).Width;  % Get Width
            
                    obj.PrevVelocity(obj.PrevVelocity(:,1) == actorID,2:end) = allActorRuntime(i).Velocity;
                    numActors = numActors + 1;
                end
            end
            
            actorsInfo.NumActors = numActors - 1;
            actorsInfo.Time = obj.SampleTime;
        end

        function [out1,out2] = getOutputSizeImpl(~)
            out1 = [1 1];
            out2 = [1 1];
        end
       
        function interface = getInterfaceImpl(~)
            import matlab.system.interface.*;
            interface = [Input("in1", Data),...
                         Input("in3", Message), ...
                         Output("out1", Data), ...
                         Output("out2", Data)];
        end

        function [out1,out2] = getOutputDataTypeImpl(~)
            out1 = "Bus: BusActorsInfo";
            out2 = "uint64";
        end

        function [out1,out2] = isOutputComplexImpl(~)
            out1 = false;
            out2 = false;
        end

        function [out1,out2] = isOutputFixedSizeImpl(~)
            out1 = true;
            out2 = true;
        end
    end

    methods (Access = protected, Static)
        function simMode = getSimulateUsingImpl
            % Return only allowed simulation mode in System block dialog
            simMode = "Interpreted execution";
        end

        function flag = showSimulateUsingImpl
            % Return false if simulation mode hidden in System block dialog
            flag = false;
        end
    end
end