function helperSLPlatooningWithRRSetup(rrAppObj,rrSimObj, nvp)
%helperSLPlatooningWithRRSetup creates required buses, variables for
% simulating the Platooning with RoadRunner Scenario Example.
%
% This helper function initializes the follower models by creating data in
% base workspace. It loads necessary control constants and sets up the
% buses required by the models. 
%
% Optional inputs
%   scenarioFcnName:
%     - Name of function which returns scenario which is compatible with
%       this example
%     - Valid values are:
%           "scenario_Platooning_01_CurvedRoad"
%           "scenario_Platooning_02_HighCurvature"
%           "scenario_Platooning_03_DecelAndStop"
%           "scenario_Platooning_04_CutInFrontOfLeader"
%
% Examples of calling this function:
%
%    helperSLPlatooningWithRRSetup(rrAppObj, rrSimObj,scenarioFcnName= "scenario_Platooning_01_CurvedRoad")
%    helperSLPlatooningWithRRSetup(rrAppObj, rrSimObj,scenarioFcnName= "scenario_Platooning_04_CutInFrontOfLeader")
%
%
%   This is a helper function for example purposes and may be removed or
%   modified in the future.

% Copyright 2022 The MathWorks, Inc.

arguments
rrAppObj = [];
rrSimObj =[];
nvp.scenarioFileName {mustBeMember(nvp.scenarioFileName,["scenario_Platooning_01_CurvedRoad", ...
                                                         "scenario_Platooning_02_HighCurvature", ...
                                                         "scenario_Platooning_03_DecelAndStop", ...
                                                         "scenario_Platooning_04_CutInFrontOfLeader"])} = "scenario_Platooning_01_CurvedRoad";
end

% List of follower models.
followerModels = {'Follower1.slx','Follower2.slx'};

% Platoon leader ID
platoonLeaderID = 1;
assignin("base","platoonLeaderID",platoonLeaderID)

% Initialize follower model info and initial pose
n = numel(followerModels);
actorPose = struct('ActorID', 0, ...
                   'Position', [0 0 0], ...         
                   'Velocity', [0 0 0], ...         
                   'Roll', 0, ...  
                   'Pitch', 0, ... 
                   'Yaw', 0, ...                   
                   'AngularVelocity', [0 0 0]);      
followerStruct = struct('ModelName','','BehaviourID','','TractorID',0,'TractorPose',actorPose,'TrailerID',0,'TrailerPose',actorPose,'PrecedingVehicleID',0);
followers = repmat(followerStruct,1,n);

% Initialize Actor Profiles
actorProfiles = struct(...
    'ActorID',1,...
    'ClassID',1,...
    'Length',4.7,...
    'Width',1.8,...
    'Height',1.4,...
    'OriginOffset',[0 0 0],...
    'FrontOverhang',0,...
    'RearOverhang',0,...
    'Wheelbase',0,...
    'Color',[0 0 0]);

% Initialize reference path
egoRefPath = struct('x',zeros(10,1),'y',zeros(10,1),'theta',zeros(10,1),'kappa',zeros(10,1),'numPoints',10);

if ~isempty(rrSimObj)
    %% Open Scenario
    openScenario(rrAppObj, strjoin([nvp.scenarioFileName, '.rrscenario'],""));
    
    %% Get Actor Poses from RRScenario
    world = rrSimObj.getScenario();
   
    % Get initial pose of each followers
    followers = getFollowerInfo(rrAppObj, world, followerModels,platoonLeaderID);
    
    
    % Get Actor Profiles
    actorProfiles = helperGetActorProfiles(world.actor_spec.world_spec.actors,"OriginOffset","VehicleCenter");
    
    %% Get reference path from RRScenario
    
    % Define reference path from RoadRunner Scenario 
    map = rrSimObj.getMap();
    % Get codegen map
    cgMap = matlabshared.roadrunner.codegenHDMap(map.map);
    % Query API
    query   = roadrunner.internal.roadrunnerHDMapQuery(cgMap);
    % Get shortest path
    start = followers(end).TractorPose;
    goal  = followers(end).TrailerPose;
    path    = query.shortestPath(start,goal);
    refPath = path.ReferencePath;
    refPath.SmoothCurvature = smoothdata(refPath.Curvature,'sgolay'); % smooth curvature
    
    numPoints = 3000;
    % Define ego reference path
    egoRefPath.x = refPath.X(1:numPoints,1);
    egoRefPath.y = refPath.Y(1:numPoints,1);
    egoRefPath.theta = refPath.Heading(1:numPoints,1);
    egoRefPath.kappa = refPath.SmoothCurvature(1:numPoints,1);
    egoRefPath.numPoints = numPoints;
end

% Assign ego reference path to the base worksapce
assignin("base","egoRefPath",egoRefPath)
% Assign actor profiles to the base worksapce
assignin("base","actorProfiles",actorProfiles)
% Assign followers to the base worksapce
assignin("base","followers",followers);
%% Setup Model Parameters

% Scene Origin
assignin("base","sceneOrigin",[42.2995, -83.6990, 0]);

% Model Sample Time
assignin("base","Ts",0.05);

%% Set the vehicle dynamics model parameters
% Initialize the 6DOF tractor trailer model parameters.
[tractorTrailerParams,vehicleDimension] = helperInitTractorTrailerParams("RoadRunner Vehicle");

% Assign the tractor trailer parameters and its dimensions into the base
% workspace
assignin("base","czWhlAxl",tractorTrailerParams.CzWhlAxl)
assignin("base","f0zWhlAxl",tractorTrailerParams.F0zWhlAxl)
assignin("base","hMax",tractorTrailerParams.Hmax)
assignin("base","kzWhlAxl",tractorTrailerParams.KzWhlAxl)
assignin("base","tractor",tractorTrailerParams.VEH)
assignin("base","trailer",tractorTrailerParams.TRA)
assignin("base","hitch",tractorTrailerParams.HTCH)

%% Setup the Longitudinal controller
% Spacing between trailer end of vehicle 1 to tractor front vehicle 2.
spacing = 7; 
% Expected euclidean spacing from tractor to tractor. (Tractor Length + Trailer Length + Spacing) 
L  = vehicleDimension.TractorLength + vehicleDimension.TrailerLength + vehicleDimension.InterConnection - vehicleDimension.Overlap + spacing;
assignin("base","L",L);

% Assign controller constants
assignin("base","C1",0.8);    % Constant gain for acceleration control
assignin("base","K1",8);      % Constant gain for velocity control
assignin("base","K2",[2 0]);  % PD gains for spacing control [P,D]
assignin("base","N",160);     % Filter coefficient for PD controller
%% Setup the Lateral controller
% Define the state matrix of the prediction model
[A, B, C] =  helperComputeStateSpaceMatrix(0.01);
assignin("base","A",A)
assignin("base","B",B)
assignin("base","C",C)

predictionHorizon = 10; % Prediction horizon of the Lane Keep Assist
minSteer = -0.75; % Minimum steering in radians
maxSteer =  0.75; % Maximum steering in radians
assignin("base","predictionHorizon",predictionHorizon)
assignin("base","minSteer",minSteer)
assignin("base","maxSteer",maxSteer)

%% Load the SNR Curves
V2VRange = 200; % V2V Range is set to 200m
if exist("V2XChannelInfo.mat","file")
snrCurvesData = load("V2XChannelInfo.mat");
channelAttributes = snrCurvesData.snrCurves;
% Adjust distance to SNR Relation based on range
maxRange = 1000; % (meters)
offsetIdx = round(max(1,min(V2VRange,maxRange))); 
channelAttributes.dist2snr(:,2) = channelAttributes.dist2snr(:,2) + channelAttributes.snrOffset(offsetIdx);
assignin("base","channelAttributes",channelAttributes);
else
error('V2XChannelInfo.mat file not found')
end

%% Create the enumeration data types needed for V2V Communication
evalin("base","helperCreateV2VEnumData");

%% Create all the Simulink Buses

% Bus for BSM message, Target and Ego Actors
helperSLCreatePlatooningUsingV2VBus
BusActorsInfo.Elements(3).Dimensions = [10 1];
BusBSM.Elements(3).Dimensions = [4 1];
assignin("base","BusActorsInfo",BusActorsInfo)
assignin("base","BusAccelerationSet4Way",BusAccelerationSet4Way)
assignin("base","BusActorPose",BusActorPose)
assignin("base","BusBrakeSystemStatus",BusBrakeSystemStatus)
assignin("base","BusBSM",BusBSM)
assignin("base","BusBSMCoreData",BusBSMCoreData)
assignin("base","BusPositionalAccuracy",BusPositionalAccuracy)
assignin("base","BusVehicleSize",BusVehicleSize)

% Get Bus Vehicle Pose and clear additional busses which are not used by
% the example
helperCreateLCBusActorsEgo(1)
evalin("base","clear BusActorsEgo")

% Bus for refPath
busInfo = Simulink.Bus.createObject(egoRefPath);
evalin("base",['BusEgoRefPath = ' busInfo.busName ';' 'clear ' busInfo.busName]);
end

%% Get follower Info
function followers = getFollowerInfo(rrAppObj,world,followerModels,platoonLeaderID)

followerModels = sort(followerModels);

% Initialize Output
for i = 1:numel(followerModels)
    followers(i).ModelName = followerModels{i};
end

% Get num of behaviours in the scenario
numOfBehaviours = size(world.actor_spec.world_spec.behaviors,1);

% Get behaviour id's for all the followers
for i = 1:numOfBehaviours
    rrSimulinkBehaviour = world.actor_spec.world_spec.behaviors(i, 1).simulink_behavior;
    if ~isempty(rrSimulinkBehaviour)
        idx = find(strcmp(followerModels, rrSimulinkBehaviour.artifact_location));
        if ~isempty(idx)
            followers(idx).BehaviourID = world.actor_spec.world_spec.behaviors(i, 1).id;
        end
    end
end

% Get the initial pose of each vehicle by matching the behaviour ids
actors = world.actor_spec.world_spec.actors;
numActors = numel(actors);
for i = 1:numActors
    actor = actors(i);
    idx = find(strcmp({followers.BehaviourID}, actor.actor_spec.behavior_id));
    if idx>0
        % Set the IDs of Tractor & Trailer
        followers(idx).TractorID = str2double(actor.actor_runtime.id);
        followers(idx).TrailerID = str2double(actor.actor_runtime.children{1});

        % Get the initial actor pose of tractor and trailer
        followers(idx).TractorPose = helperGetActorPose(actors,followers(idx).TractorID); 
        followers(idx).TrailerPose = helperGetActorPose(actors,followers(idx).TrailerID);

        % Get the vehicle speed for roadrunner scenario
        vehSpeed = str2double(rrAppObj.getScenarioVariable([followers(idx).ModelName(1:end-4) 'InitialSpeed']));
        velocity = [vehSpeed 0 0]; % The velocity is in vehicle coordinates and  the vehicle is moving forward.

        % Update the velocity in the initial actor pose
        followers(idx).TractorPose.Velocity = velocity; 
        followers(idx).TrailerPose.Velocity = velocity; 
    end
end

for i = 1:numel(followerModels)
    if i==1 % If it is the 1st follower
        followers(i).PrecedingVehicleID = platoonLeaderID;
    else
        followers(i).PrecedingVehicleID = followers(i-1).TractorID;
    end
end
end